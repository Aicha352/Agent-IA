# AgentIA V1 → V6

Plateforme SaaS de gestion + Agent IA pour petites entreprises.

## V1 — MVP
- choix du métier
- entreprise
- produits/services
- stock
- clients
- commandes
- statistiques
- Agent IA

## V2 — Professionnel
- inscription / connexion JWT
- utilisateurs
- multi-entreprises
- rôles
- données isolées par entreprise

## V3 — IA
- conversations sauvegardées
- contexte entreprise
- outils métier
- moteur local de secours
- point d'extension LLM

## V4 — Data Science
- KPI
- produits les plus vendus
- stocks faibles
- prévision simple
- recommandations

## V5 — Réseaux sociaux
- WhatsApp
- Instagram
- Facebook
- TikTok
- YouTube
- architecture de connexion

## V6 — SaaS
- Starter : 5 000 F/mois
- Business : 10 000 F/mois
- Pro : 25 000 F/mois
- Enterprise : sur devis
- abonnement
- checkout de démonstration
- paiement en architecture "provider"

### Important
Les vraies API WhatsApp/Instagram/Facebook/TikTok/YouTube et les vrais paiements ne peuvent pas être activés sans comptes développeur, clés, secrets, webhooks et validation des fournisseurs. Le projet contient le socle et des endpoints de préparation, pas des secrets fictifs.

## Installation sans venv

### Backend
```powershell
cd backend
pip install -r requirements.txt
python manage.py makemigrations api
python manage.py migrate
python manage.py runserver
```

### Frontend
Dans un autre terminal :
```powershell
cd frontend
npm install
npm run dev
```

Frontend : http://localhost:5173/
Backend : http://127.0.0.1:8000/
Health : http://127.0.0.1:8000/api/health/

## Compte
L'écran d'inscription crée automatiquement une entreprise et un abonnement d'essai.

## Suite après V6
- PostgreSQL
- Docker
- vrais providers de paiement
- vrais OAuth sociaux
- LLM en production
- monitoring
- sauvegardes
- sécurité avancée
- déploiement cloud
