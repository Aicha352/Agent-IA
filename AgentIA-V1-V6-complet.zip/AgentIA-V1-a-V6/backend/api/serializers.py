from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Business,Product,Client,Order

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True,min_length=6)
    class Meta:
        model=User
        fields=["username","email","password"]
    def create(self,validated_data):
        return User.objects.create_user(**validated_data)

class BusinessSerializer(serializers.ModelSerializer):
    class Meta:
        model=Business
        fields="__all__"

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model=Product
        fields="__all__"

class ClientSerializer(serializers.ModelSerializer):
    class Meta:
        model=Client
        fields="__all__"

class OrderSerializer(serializers.ModelSerializer):
    product_name=serializers.CharField(source="product.name",read_only=True)
    class Meta:
        model=Order
        fields="__all__"
