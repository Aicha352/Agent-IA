from django.conf import settings
from django.db import models

class Business(models.Model):
    TYPES = [
        ("commerce","Commerce"),("restaurant","Restaurant"),("couture","Couture"),
        ("coiffure","Coiffure"),("agriculture","Agriculture"),("elevage","Élevage"),
        ("production","Production"),("artisanat","Artisanat"),("immobilier","Immobilier"),
        ("transport","Transport"),("education","Éducation"),("autre","Autre")
    ]
    owner = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE,related_name="businesses")
    name = models.CharField(max_length=150)
    business_type = models.CharField(max_length=50,choices=TYPES,default="autre")
    city = models.CharField(max_length=100,blank=True)
    phone = models.CharField(max_length=30,blank=True)
    hours = models.CharField(max_length=100,blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class BusinessMember(models.Model):
    business = models.ForeignKey(Business,on_delete=models.CASCADE,related_name="members")
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    role = models.CharField(max_length=20,default="staff")
    class Meta:
        unique_together = ("business","user")

class Product(models.Model):
    business = models.ForeignKey(Business,on_delete=models.CASCADE,related_name="products")
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=12,decimal_places=2,default=0)
    stock = models.IntegerField(default=0)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Client(models.Model):
    business = models.ForeignKey(Business,on_delete=models.CASCADE,related_name="clients")
    name = models.CharField(max_length=150)
    phone = models.CharField(max_length=30,blank=True)
    email = models.EmailField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Order(models.Model):
    STATUSES = [
        ("En attente","En attente"),("Confirmée","Confirmée"),
        ("En préparation","En préparation"),("Livrée","Livrée"),("Annulée","Annulée")
    ]
    business = models.ForeignKey(Business,on_delete=models.CASCADE,related_name="orders")
    client = models.ForeignKey(Client,null=True,blank=True,on_delete=models.SET_NULL)
    client_name = models.CharField(max_length=150)
    product = models.ForeignKey(Product,on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1)
    total = models.DecimalField(max_digits=12,decimal_places=2,default=0)
    status = models.CharField(max_length=30,choices=STATUSES,default="En attente")
    created_at = models.DateTimeField(auto_now_add=True)

class AgentConversation(models.Model):
    business = models.ForeignKey(Business,on_delete=models.CASCADE,related_name="conversations")
    user = models.ForeignKey(settings.AUTH_USER_MODEL,null=True,blank=True,on_delete=models.SET_NULL)
    title = models.CharField(max_length=150,blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

class AgentMessage(models.Model):
    conversation = models.ForeignKey(AgentConversation,on_delete=models.CASCADE,related_name="messages")
    role = models.CharField(max_length=20)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

class SocialConnection(models.Model):
    business = models.ForeignKey(Business,on_delete=models.CASCADE,related_name="socials")
    platform = models.CharField(max_length=40)
    account_name = models.CharField(max_length=150,blank=True)
    status = models.CharField(max_length=40,default="Préparé")
    external_id = models.CharField(max_length=200,blank=True)

class SubscriptionPlan(models.Model):
    code = models.CharField(max_length=30,unique=True)
    name = models.CharField(max_length=80)
    monthly_price = models.DecimalField(max_digits=12,decimal_places=2)
    max_products = models.IntegerField(default=30)
    max_clients = models.IntegerField(default=100)
    max_orders = models.IntegerField(default=300)
    ai_enabled = models.BooleanField(default=True)
    social_enabled = models.BooleanField(default=False)
    analytics_enabled = models.BooleanField(default=True)

class Subscription(models.Model):
    business = models.OneToOneField(Business,on_delete=models.CASCADE,related_name="subscription")
    plan = models.ForeignKey(SubscriptionPlan,on_delete=models.PROTECT)
    status = models.CharField(max_length=20,default="trial")
    provider = models.CharField(max_length=40,default="mock")
    reference = models.CharField(max_length=150,blank=True)
    started_at = models.DateTimeField(auto_now_add=True)

class Payment(models.Model):
    business = models.ForeignKey(Business,on_delete=models.CASCADE,related_name="payments")
    subscription = models.ForeignKey(Subscription,null=True,blank=True,on_delete=models.SET_NULL)
    amount = models.DecimalField(max_digits=12,decimal_places=2)
    currency = models.CharField(max_length=10,default="XOF")
    status = models.CharField(max_length=20,default="pending")
    provider = models.CharField(max_length=40,default="mock")
    reference = models.CharField(max_length=150,unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
