from django.contrib import admin
from .models import *
for m in [Business,BusinessMember,Product,Client,Order,AgentConversation,AgentMessage,SocialConnection,SubscriptionPlan,Subscription,Payment]:
    admin.site.register(m)
