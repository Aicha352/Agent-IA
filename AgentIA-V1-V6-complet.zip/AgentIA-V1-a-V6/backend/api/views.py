import uuid
from decimal import Decimal
from django.contrib.auth.models import User
from django.db import transaction
from django.db.models import Sum
from django.http import JsonResponse
from rest_framework.decorators import api_view,permission_classes
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.response import Response
from .models import *
from .serializers import *
from .services import analytics,forecast,recommendations,agent_answer

def business_for(request):
    bid=request.headers.get("X-Business-ID") or request.query_params.get("business_id")
    qs=Business.objects.filter(owner=request.user)
    if bid:
        try:return qs.get(pk=int(bid))
        except (Business.DoesNotExist,ValueError,TypeError):return None
    return qs.first()

def health(request):
    return JsonResponse({"status":"ok","service":"AgentIA","version":"V1-V6"})

@api_view(["POST"])
@permission_classes([AllowAny])
def register(request):
    s=RegisterSerializer(data=request.data)
    if not s.is_valid(): return Response(s.errors,400)
    user=s.save()
    b=Business.objects.create(owner=user,name=request.data.get("business_name","Mon entreprise"),business_type=request.data.get("business_type","autre"),city=request.data.get("city",""),phone=request.data.get("phone",""))
    BusinessMember.objects.create(business=b,user=user,role="owner")
    defaults=[
        ("starter","Starter",5000,30,100,300,True,False,True),
        ("business","Business",10000,200,500,2000,True,True,True),
        ("pro","Pro",25000,1000,5000,10000,True,True,True),
        ("enterprise","Enterprise",0,100000,100000,100000,True,True,True)
    ]
    for code,name,price,mp,mc,mo,ai,social,ana in defaults:
        SubscriptionPlan.objects.get_or_create(code=code,defaults={"name":name,"monthly_price":price,"max_products":mp,"max_clients":mc,"max_orders":mo,"ai_enabled":ai,"social_enabled":social,"analytics_enabled":ana})
    Subscription.objects.create(business=b,plan=SubscriptionPlan.objects.get(code="starter"),status="trial")
    return Response({"message":"Compte créé","business_id":b.id},201)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def me(request):
    return Response({"id":request.user.id,"username":request.user.username,"email":request.user.email,"businesses":BusinessSerializer(Business.objects.filter(owner=request.user),many=True).data})

@api_view(["GET","POST"])
@permission_classes([IsAuthenticated])
def businesses(request):
    if request.method=="GET":
        return Response(BusinessSerializer(Business.objects.filter(owner=request.user),many=True).data)
    s=BusinessSerializer(data={**request.data,"owner":request.user.id})
    if s.is_valid():
        b=s.save();BusinessMember.objects.get_or_create(business=b,user=request.user,defaults={"role":"owner"})
        return Response(BusinessSerializer(b).data,201)
    return Response(s.errors,400)

@api_view(["GET","POST","PUT","DELETE"])
@permission_classes([IsAuthenticated])
def products(request,pk=None):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    qs=Product.objects.filter(business=b)
    if request.method=="GET":
        if pk:
            try:return Response(ProductSerializer(qs.get(pk=pk)).data)
            except Product.DoesNotExist:return Response({"error":"Produit introuvable"},404)
        return Response(ProductSerializer(qs,many=True).data)
    if request.method=="POST":
        s=ProductSerializer(data={**request.data,"business":b.id})
        if s.is_valid():return Response(ProductSerializer(s.save()).data,201)
        return Response(s.errors,400)
    try:o=qs.get(pk=pk)
    except Product.DoesNotExist:return Response({"error":"Produit introuvable"},404)
    if request.method=="PUT":
        s=ProductSerializer(o,data={**request.data,"business":b.id},partial=True)
        if s.is_valid():return Response(ProductSerializer(s.save()).data)
        return Response(s.errors,400)
    o.active=False;o.save();return Response({"message":"Produit supprimé"})

@api_view(["GET","POST","PUT","DELETE"])
@permission_classes([IsAuthenticated])
def clients(request,pk=None):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    qs=Client.objects.filter(business=b)
    if request.method=="GET":
        if pk:
            try:return Response(ClientSerializer(qs.get(pk=pk)).data)
            except Client.DoesNotExist:return Response({"error":"Client introuvable"},404)
        return Response(ClientSerializer(qs,many=True).data)
    if request.method=="POST":
        s=ClientSerializer(data={**request.data,"business":b.id})
        if s.is_valid():return Response(ClientSerializer(s.save()).data,201)
        return Response(s.errors,400)
    try:o=qs.get(pk=pk)
    except Client.DoesNotExist:return Response({"error":"Client introuvable"},404)
    if request.method=="PUT":
        s=ClientSerializer(o,data={**request.data,"business":b.id},partial=True)
        if s.is_valid():return Response(ClientSerializer(s.save()).data)
        return Response(s.errors,400)
    o.delete();return Response({"message":"Client supprimé"})

@api_view(["GET","POST","PUT","DELETE"])
@permission_classes([IsAuthenticated])
def orders(request,pk=None):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    qs=Order.objects.filter(business=b).select_related("product","client")
    if request.method=="GET":
        if pk:
            try:return Response(OrderSerializer(qs.get(pk=pk)).data)
            except Order.DoesNotExist:return Response({"error":"Commande introuvable"},404)
        return Response(OrderSerializer(qs,many=True).data)
    if request.method=="POST":
        try:p=Product.objects.get(pk=int(request.data.get("product_id")),business=b,active=True)
        except (Product.DoesNotExist,TypeError,ValueError):return Response({"error":"Produit introuvable"},400)
        q=int(request.data.get("quantity",1))
        if q<=0:return Response({"error":"Quantité invalide"},400)
        if p.stock<q:return Response({"error":f"Stock insuffisant : {p.stock}"},400)
        c=None
        if request.data.get("client_id"):c=Client.objects.filter(pk=request.data["client_id"],business=b).first()
        with transaction.atomic():
            p.stock-=q;p.save()
            o=Order.objects.create(business=b,client=c,client_name=request.data.get("client_name") or (c.name if c else "Client"),product=p,quantity=q,total=p.price*q)
        return Response(OrderSerializer(o).data,201)
    try:o=qs.get(pk=pk)
    except Order.DoesNotExist:return Response({"error":"Commande introuvable"},404)
    if request.method=="PUT":
        new=request.data.get("status",o.status)
        if new not in dict(Order.STATUSES):return Response({"error":"Statut invalide"},400)
        old=o.status
        if old!="Annulée" and new=="Annulée":o.product.stock+=o.quantity;o.product.save()
        elif old=="Annulée" and new!="Annulée":
            if o.product.stock<o.quantity:return Response({"error":"Stock insuffisant"},400)
            o.product.stock-=o.quantity;o.product.save()
        o.status=new;o.save()
        return Response(OrderSerializer(o).data)
    if o.status!="Annulée":o.product.stock+=o.quantity;o.product.save()
    o.delete();return Response({"message":"Commande supprimée"})

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def dashboard(request):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    return Response(analytics(b))

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def analytics_view(request):
    b=business_for(request);return Response(analytics(b)) if b else Response({"error":"Entreprise introuvable"},400)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def forecast_view(request):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    days=max(1,min(int(request.query_params.get("days",7)),90))
    return Response(forecast(b,days))

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def recommendations_view(request):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    return Response({"recommendations":recommendations(b)})

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def agent_chat(request):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    text=str(request.data.get("message","")).strip()
    if not text:return Response({"error":"Message vide"},400)
    cid=request.data.get("conversation_id")
    c=AgentConversation.objects.filter(id=cid,business=b).first() if cid else None
    if not c:c=AgentConversation.objects.create(business=b,user=request.user,title=text[:80])
    AgentMessage.objects.create(conversation=c,role="user",content=text)
    answer=agent_answer(b,text)
    AgentMessage.objects.create(conversation=c,role="assistant",content=answer)
    return Response({"conversation_id":c.id,"reply":answer})

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def conversations(request):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    return Response([{"id":c.id,"title":c.title,"messages":[{"role":m.role,"content":m.content} for m in c.messages.all()]} for c in AgentConversation.objects.filter(business=b).order_by("-id")])

@api_view(["GET","POST"])
@permission_classes([IsAuthenticated])
def social(request):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    if request.method=="GET":
        return Response(list(SocialConnection.objects.filter(business=b).values("id","platform","account_name","status","external_id")))
    p=request.data.get("platform")
    o,_=SocialConnection.objects.update_or_create(business=b,platform=p,defaults={"account_name":request.data.get("account_name",""),"status":"Préparé"})
    return Response({"id":o.id,"platform":o.platform,"status":o.status,"message":"Connexion préparée. Une vraie API OAuth/webhook est nécessaire."},201)

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def plans(request):
    if not SubscriptionPlan.objects.exists():
        for code,name,price in [("starter","Starter",5000),("business","Business",10000),("pro","Pro",25000),("enterprise","Enterprise",0)]:
            SubscriptionPlan.objects.create(code=code,name=name,monthly_price=price)
    return Response(list(SubscriptionPlan.objects.values("code","name","monthly_price","max_products","max_clients","max_orders","ai_enabled","social_enabled","analytics_enabled")))

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def subscription(request):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    s=getattr(b,"subscription",None)
    if not s:return Response({"error":"Aucun abonnement"},404)
    return Response({"plan":s.plan.name,"code":s.plan.code,"price":float(s.plan.monthly_price),"status":s.status,"provider":s.provider,"reference":s.reference})

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def checkout(request):
    b=business_for(request)
    if not b:return Response({"error":"Entreprise introuvable"},400)
    try:p=SubscriptionPlan.objects.get(code=request.data.get("plan"))
    except SubscriptionPlan.DoesNotExist:return Response({"error":"Plan introuvable"},404)
    s,_=Subscription.objects.get_or_create(business=b,defaults={"plan":p})
    s.plan=p;s.status="active";s.provider="mock";s.reference="SUB-"+uuid.uuid4().hex[:12];s.save()
    pay=Payment.objects.create(business=b,subscription=s,amount=p.monthly_price,currency="XOF",status="paid" if p.monthly_price==0 else "pending",provider="mock",reference="PAY-"+uuid.uuid4().hex[:12])
    return Response({"message":"Checkout de démonstration","plan":p.name,"amount":float(p.monthly_price),"currency":"XOF","payment_status":pay.status,"reference":pay.reference},201)
