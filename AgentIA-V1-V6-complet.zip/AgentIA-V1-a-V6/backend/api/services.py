from decimal import Decimal
from django.db.models import Sum
from .models import Product, Client, Order

def agent_answer(business, text):
    m = (text or "").lower().strip()
    products = Product.objects.filter(business=business,active=True)
    clients = Client.objects.filter(business=business)
    orders = Order.objects.filter(business=business).exclude(status="Annulée")
    revenue = orders.aggregate(x=Sum("total"))["x"] or Decimal("0")

    if any(x in m for x in ["bonjour","salut","hello","bonsoir"]):
        return f"Bonjour 👋 Je suis votre Agent IA pour {business.name}."
    if "stock" in m or "reste" in m:
        return "📦 Stocks :\n" + ("\n".join(f"• {p.name} : {p.stock}" for p in products) if products.exists() else "Aucun produit.")
    if "produit" in m:
        return "📦 Produits :\n" + ("\n".join(f"• {p.name} — {p.price:,.0f} F CFA" for p in products) if products.exists() else "Aucun produit.")
    if "prix" in m or "coûte" in m or "cout" in m:
        return "💰 Prix :\n" + ("\n".join(f"• {p.name} : {p.price:,.0f} F CFA" for p in products) if products.exists() else "Aucun produit.")
    if "client" in m:
        return f"👥 Vous avez {clients.count()} client(s)."
    if "commande" in m:
        return f"🛒 {orders.count()} commande(s) — 💰 {revenue:,.0f} F CFA."
    if "statistique" in m or "chiffre d'affaire" in m or m == "ca":
        return f"📊 CA : {revenue:,.0f} F CFA\n🛒 Commandes : {orders.count()}\n👥 Clients : {clients.count()}\n📦 Produits : {products.count()}"
    return "🤖 Je peux consulter vos produits, prix, stocks, commandes, clients et statistiques."

def analytics(business):
    products = Product.objects.filter(business=business,active=True)
    orders = Order.objects.filter(business=business).exclude(status="Annulée")
    revenue = orders.aggregate(x=Sum("total"))["x"] or Decimal("0")
    best = orders.values("product__name").annotate(qty=Sum("quantity")).order_by("-qty").first()
    low = list(products.filter(stock__lte=5).values("id","name","stock"))
    return {
        "revenue": float(revenue),
        "orders": orders.count(),
        "clients": Client.objects.filter(business=business).count(),
        "products": products.count(),
        "low_stock": low,
        "best_product": best,
        "forecast_7_days": forecast(business,7),
    }

def forecast(business,days=7):
    orders = Order.objects.filter(business=business).exclude(status="Annulée")
    by_day = {}
    for o in orders:
        day = o.created_at.date()
        by_day[day] = by_day.get(day,Decimal("0")) + o.total
    values = list(by_day.values())[-30:]
    avg = sum(values,Decimal("0")) / len(values) if values else Decimal("0")
    return {"method":"moyenne quotidienne","history_days":len(values),"daily_average":float(avg),"forecast":float(avg*days),"days":days}

def recommendations(business):
    a = analytics(business)
    result = []
    if a["low_stock"]:
        result.append("Réapprovisionner : " + ", ".join(x["name"] for x in a["low_stock"]))
    if a["best_product"]:
        result.append("Mettre davantage en avant : " + a["best_product"]["product__name"])
    if not result:
        result.append("Continuer à enregistrer les ventes pour améliorer les analyses.")
    return result
