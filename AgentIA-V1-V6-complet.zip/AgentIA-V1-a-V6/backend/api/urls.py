from django.urls import path
from . import views

urlpatterns = [
    path("health/",views.health),
    path("register/",views.register),
    path("me/",views.me),
    path("businesses/",views.businesses),
    path("products/",views.products),
    path("products/<int:pk>/",views.products),
    path("clients/",views.clients),
    path("clients/<int:pk>/",views.clients),
    path("orders/",views.orders),
    path("orders/<int:pk>/",views.orders),
    path("dashboard/",views.dashboard),
    path("analytics/",views.analytics_view),
    path("forecast/",views.forecast_view),
    path("recommendations/",views.recommendations_view),
    path("agent/chat/",views.agent_chat),
    path("agent/conversations/",views.conversations),
    path("social/",views.social),
    path("plans/",views.plans),
    path("subscription/",views.subscription),
    path("checkout/",views.checkout),
]
